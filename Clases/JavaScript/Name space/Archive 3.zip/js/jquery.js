
function codigoDeArtista() {
	x = 40;
}